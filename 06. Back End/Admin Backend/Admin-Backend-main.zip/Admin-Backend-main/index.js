require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connection = require('./db')
const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// API route to fetch data for widgets
app.get('/api/widgets', (req, res) => {

  const queries = {
    user: 'SELECT COUNT(*) as amount FROM USERS',
    order: 'SELECT COUNT(*) as amount FROM TICKET',
    earning: 'SELECT SUM(amount) as amount FROM TRANSACTION',
    balance: `SELECT SUM(amount) as amount FROM TRANSACTION  WHERE type!= 'Refund'`,
  };

  const types = ['user', 'order', 'earning', 'balance'];
  let results = {};

  types.forEach((type) => {
    connection.query(queries[type], (err, result) => {
      if (err) {
        console.error('Error executing query:', err);
        return res.status(500).json({ error: 'Error fetching data' });
      }

      results[type] = result[0].amount;

      // Once all results are fetched, send the response
      if (Object.keys(results).length === types.length) {
        res.json(results);
      }
    });
  });
});

app.get("/api/sales", (req, res) => {
    const todayQuery = `SELECT SUM(amount) as todaySales FROM TRANSACTION WHERE DATE(date) = CURDATE() AND type!= 'Refund'`;
    const lastWeekQuery = `SELECT SUM(amount) as lastWeekSales FROM TRANSACTION WHERE YEARWEEK(date, 1) = YEARWEEK(CURDATE(), 1) - 1 AND type!= 'Refund'`;
    const lastMonthQuery = `SELECT SUM(amount) as lastMonthSales FROM TRANSACTION WHERE MONTH(date) = MONTH(CURDATE()) - 1 AND type!= 'Refund'`;
  
    connection.query(todayQuery, (err, todayResult) => {
      if (err) {
        console.error("Error fetching today's sales:", err);
        return res.status(500).json({ error: "Error fetching today's sales" });
      }
  
    connection.query(lastWeekQuery, (err, lastWeekResult) => {
        if (err) {
          console.error("Error fetching last week's sales:", err);
          return res.status(500).json({ error: "Error fetching last week's sales" });
        }
  
    connection.query(lastMonthQuery, (err, lastMonthResult) => {
          if (err) {
            console.error("Error fetching last month's sales:", err);
            return res.status(500).json({ error: "Error fetching last month's sales" });
          }
  
          res.json({
            todaySales: todayResult[0].todaySales || 0,
            lastWeekSales: lastWeekResult[0].lastWeekSales || 0,
            lastMonthSales: lastMonthResult[0].lastMonthSales || 0,
          });
        });
      });
    });
  });

  app.get("/api/chart-sales", (req, res) => {
    const query = `SELECT MONTHNAME(date) AS name, SUM(amount) AS Total FROM TRANSACTION WHERE type != 'Refund' GROUP BY MONTH(date), MONTHNAME(date)ORDER BY MONTH(date);`;
  
    connection.query(query, (err, result) => {
      if (err) {
        console.error("Error fetching sales data for chart:", err);
        return res.status(500).json({ error: "Error fetching sales data" });
      }
  
      res.json({
        salesData: result || []
      });
    });
  });
  
app.get('/api/transactions', (req, res) => {
    const query = `SELECT 
    t.transactionid, 
    CONCAT(u.fname, ' ', u.lname) AS customer, 
    t.date, 
    t.amount, 
    t.type, 
    t.status
    FROM TRANSACTION t
    JOIN USERS u ON t.userid = u.userid
    WHERE t.type != 'Refund'
    ORDER BY t.date DESC;`;
  
    connection.query(query, (err, result) => {
      if (err) {
        console.error("Error fetching transaction data:", err);
        res.status(500).json({ error: "Failed to fetch transaction data" });
      } else {
        res.json(result);
      }
    });
});

// Fetch bookings data for booking datatable
app.get('/api/bookings', (req, res) => {
    const query = `
      SELECT 
        b.ticketNo, 
        CONCAT(u.fname, ' ', u.lname) AS customer, 
        b.issuedDate, 
        b.ticketPrice, 
        b.status 
      FROM TICKET b
      JOIN USERS u ON b.passengerid = u.userid
      ORDER BY b.issuedDate DESC;
    `;
  
    connection.query(query, (err, result) => {
      if (err) {
        console.error('Error fetching bookings:', err);
        return res.status(500).json({ error: 'Failed to fetch booking data' });
      }
      res.json(result);
    });
});

app.get('/api/transactions', (req, res) => {
    const query = `
      SELECT 
        t.transactionid, 
        CONCAT(u.fname, ' ', u.lname) AS customer, 
        t.date, 
        t.amount, 
        t.type, 
        t.status 
      FROM TRANSACTION t
      JOIN USERS u ON t.userid = u.userid
      ORDER BY t.date DESC;
    `;
  
    connection.query(query, (err, result) => {
      if (err) {
        console.error('Error fetching transaction data:', err);
        return res.status(500).json({ error: 'Failed to fetch transaction data' });
      }
      res.json(result);
    });
});

app.get('/api/schedules', (req, res) => {
    const query = `
      SELECT 
        s.scheduleid, 
        s.date, 
        s.departuretime, 
        s.routeid,
        s.vehicleid,
        s.status
      FROM SCHEDULE s
      ORDER BY s.date DESC, s.departuretime DESC;
    `;
  
    connection.query(query, (err, result) => {
      if (err) {
        console.error('Error fetching schedule data:', err);
        return res.status(500).json({ error: 'Failed to fetch schedule data' });
      }
      console.log(result)
      res.json(result);
    });
  });

  app.get('/api/users', (req, res) => {
    const query =`
    SELECT 
      u.userid, 
      u.fname, 
      u.lname, 
      u.email, 
      u.userstate 
    FROM USERS u
    ORDER BY u.userid DESC;
  `;
  
    connection.query(query, (err, result) => {
      if (err) {
        console.error('Error fetching users:', err);
        return res.status(500).json({ error: 'Failed to fetch user data' });
      }
      res.json(result);
      console.log(result);
    });
  });

// Fetch all saved locations
app.get('/api/locations', (req, res) => {
  const query = 'SELECT LOCATIONID, LAT, LNG, NAMEID FROM BUSSTOP_LOCATIONS;';
  connection.query(query, (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Error fetching locations' });
    }
    res.json(result);
  });
});

// Add a new location
app.post('/api/locations', (req, res) => {
  const { lat, lng, name } = req.body;
  const query = 'INSERT INTO BUSSTOP_LOCATIONS (name, lat, lng) VALUES (?, ?, ?);';
  connection.query(query, [name, lat, lng], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Error saving location' });
    }
    res.json({ message: 'Location added successfully' });
  });
});

// Delete a location
app.delete('/api/locations/:id', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM BUSSTOP_LOCATIONS WHERE id = ?;';
  connection.query(query, [id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Error deleting location' });
    }
    res.json({ message: 'Location deleted successfully' });
  });
});

app.get('/api/bus-locations', (req, res) => {
  const query = `
    SELECT 
      regNo, 
      lat, 
      lng
    FROM BUS_LOCATIONS
  `;

  connection.query(query, (err, result) => {
    if (err) {
      console.error('Error fetching bus location data:', err);
      return res.status(500).json({ error: 'Failed to fetch bus location data' });
    }
    res.json(result);
    console.log(result)
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
