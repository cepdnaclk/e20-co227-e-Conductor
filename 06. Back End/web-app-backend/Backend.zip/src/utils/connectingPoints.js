// Function to find the conncting bus stops

export default async function connectingPoints(fromLocation, toLocation) {
  // Function Body
  const points = [fromLocation, toLocation];

  console.log("points", points);
  return points;
}
