import React, { useEffect, useState } from 'react';
import { GoogleMap, Marker, useLoadScript } from '@react-google-maps/api';
import { Button, TextField, Box,} from '@mui/material';
import axios from 'axios';

const mapContainerStyle = {
  width: '100%',
  height: '800px',
  margin: '20px'
};

const center = {
  lat: 7.2906,  // Kandy's latitude
  lng: 80.6337, // Kandy's longitude
};

const libraries = ['places'];

const LocationManager = () => {
  const { isLoaded } = useLoadScript({
    googleMapsApiKey: 'AIzaSyB8KTu2cHiVsaBQAjxVFfe5YSjUaQHZVec',
    libraries,
  });

  const [locations, setLocations] = useState([]);
  const [newLocation, setNewLocation] = useState(null);
  const [busLocations, setBusLocations] = useState([]); // Bus location state
  const [searchInput, setSearchInput] = useState('');
  const [map, setMap] = useState(null);
  const [customMarkerIcon, setCustomMarkerIcon] = useState(null);
  const [busMarkerIcon, setBusMarkerIcon] = useState(null);

  useEffect(() => {
    // Fetch all regular locations from the database
    const fetchLocations = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/locations');
        const fetchedLocations = response.data.map((location) => ({
          ...location,
          lat: parseFloat(location.lat),
          lng: parseFloat(location.lng),
        }));
        setLocations(fetchedLocations);
      } catch (err) {
        console.error('Error fetching locations:', err);
      }
    };
    
    // Fetch bus locations from a different table
    const fetchBusLocations = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/bus-locations');
        const fetchedBusLocations = response.data.map((bus) => ({
          ...bus,
          lat: parseFloat(bus.lat),
          lng: parseFloat(bus.lng),
        }));
        setBusLocations(fetchedBusLocations);
      } catch (err) {
        console.error('Error fetching bus locations:', err);
      }
    };

    fetchLocations();
    fetchBusLocations();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      // Set the custom marker icon for regular locations
      setCustomMarkerIcon({
        path: "M12 2C8.13 2 5 5.13 5 9c0 4.25 6.08 11.54 6.29 11.76.23.23.61.23.84 0C12.92 20.54 19 13.25 19 9c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5S10.62 6.5 12 6.5s2.5 1.12 2.5 2.5S13.38 11.5 12 11.5z",
        fillColor: "#4285F4", // Change to your desired color for regular locations
        fillOpacity: 1,
        strokeWeight: 2, // Optional: add a border
        strokeColor: "#2C6EBC",
        scale: 2,
        anchor: new window.google.maps.Point(12, 20),
      });
  
      // Set a different icon for bus locations
      setBusMarkerIcon({
        path: "M12 2C8.13 2 5 5.13 5 9c0 4.25 6.08 11.54 6.29 11.76.23.23.61.23.84 0C12.92 20.54 19 13.25 19 9c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5S10.62 6.5 12 6.5s2.5 1.12 2.5 2.5S13.38 11.5 12 11.5z",
        fillColor: "#FF0000", // Change to your desired color for bus locations
        fillOpacity: 1,
        strokeWeight: 2,
        strokeColor: "#990000",
        scale: 2,
        anchor: new window.google.maps.Point(12, 20),
      });
    }
  }, [isLoaded]);

  const handleMapClick = (event) => {
    setNewLocation({ lat: event.latLng.lat(), lng: event.latLng.lng() });
  };

 const handleAddLocation = async () => {
    if (newLocation) {
      const response = await axios.post('http://localhost:5000/api/locations', {
        lat: newLocation.lat,
        lng: newLocation.lng,
        name: searchInput || 'Unnamed',
      });
      setLocations([...locations, { ...newLocation, name: searchInput }]);
      setNewLocation(null);
      setSearchInput('');
    }
  };

  const handleDeleteLocation = async (id) => {
    await axios.delete(`http://localhost:5000/api/locations/${id}`);
    setLocations(locations.filter(location => location.id !== id));
  };

  const handleSearchChange = (e) => {
    setSearchInput(e.target.value);
  };

  if (!isLoaded) return <div>Loading...</div>;

  return (
    <div>
      <Box sx={{ margin: 2}}>
        <TextField
            sx={{ width: '40vh'}}
          label="Search Location"
          value={searchInput}
          onChange={handleSearchChange}
        />
        <Button variant="contained" sx={{ margin: 1}} onClick={handleAddLocation}>
          Add Location
        </Button>
      </Box>
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        zoom={12}
        center={center}
        onClick={handleMapClick}
        onLoad={(mapInstance) => setMap(mapInstance)}
      >
        {locations.map((location) => (
          <Marker
            key={location.LOCATIONID}
            position={{ lat: Number(location.LAT), lng: Number(location.LNG) }}
            label={location.NAMEID || 'Unnamed'}
            icon={customMarkerIcon}
          />
        ))}
        {busLocations.map((bus) => (
          <Marker
            key={bus.regNo}
            position={{ lat: Number(bus.lat), lng: Number(bus.lng) }}
            label={bus.regNo || 'Bus'}
            icon={busMarkerIcon}
          />
        ))}
        {newLocation && (
          <Marker
            position={{ lat: newLocation.lat, lng: newLocation.lng }}
            label="New Location"
          />
        )}
      </GoogleMap>

    </div>
  );
};

export default LocationManager;
