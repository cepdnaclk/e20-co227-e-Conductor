import "./datatable.scss";
import { DataGrid } from "@mui/x-data-grid";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from 'axios';

export const Datatable = () => {
  const [data, setData] = useState([]);

  // Fetch user data from backend
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/users');  // Adjust the endpoint as necessary
        setData(response.data);  // Assume the response contains the list of users
      } catch (err) {
        console.error('Error fetching user data:', err);
      }
    };
    fetchData();
  }, []);

  const handleDelete = (id) => {
    setData(data.filter((item) => item.userid !== id));
    // You might also want to delete the user from the backend here using axios
  };

  const actionColumn = [
    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => {
        return (
          <div className="cellAction">
            <Link to={`/users/${params.row.userid}`} style={{ textDecoration: "none" }}>
              <div className="viewButton">View</div>
            </Link>
            <div
              className="deleteButton"
              onClick={() => handleDelete(params.row.userid)}
            >
              Terminate
            </div>
          </div>
        );
      },
    },
  ];
  const userColumns = [
    { field: "userid", headerName: "ID", width: 70 },
    {
      field: "user",
      headerName: "User",
      width: 230,
      renderCell: (params) => {
        return (
          <div className="cellWithImg">
            <img className="cellImg" src={params.row.img || 'default-avatar.jpg'} alt="avatar" />
            {`${params.row.fname} ${params.row.lname}`}
          </div>
        );
      },
    },
    {
      field: "email",
      headerName: "Email",
      width: 230,
    },
    {
      field: "userstate",
      headerName: "Status",
      width: 160,
      renderCell: (params) => {
        return (
          <div className={`cellWithStatus ${params.row.userstate}`}>
            {params.row.userstate}
          </div>
        );
      },
    },
  ];

  return (
    <div className="datatable">
      <div className="datatableTitle">
        Users
        <Link to="/users/new" className="link">
          Add New
        </Link>
      </div>
      <DataGrid
        className="datagrid"
        rows={data}
        columns={userColumns.concat(actionColumn)}
        pageSize={9}
        rowsPerPageOptions={[9]}
        checkboxSelection
        getRowId={(row) => row.userid}
      />
    </div>
  );
};

export const BookingDatatable = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/bookings');
        // Add a unique 'id' property using ticketNo for each row
        const formattedData = response.data.map((item) => ({
          id: item.ticketNo,  // Using ticketNo as the unique identifier
          ...item
        }));
        setData(formattedData);
      } catch (err) {
        console.error('Error fetching booking data:', err);
      }
    };
    fetchData();
  }, []);

  const handleDelete = (ticketNo) => {
    setData(data.filter((item) => item.ticketNo !== ticketNo));
    // Optionally, you can add an axios request here to delete the booking from the backend
  };

  const actionColumn = [
    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => {
        return (
          <div className="cellAction">
            <Link to={`/bookings/${params.row.ticketNo}`} style={{ textDecoration: "none" }}>
              <div className="viewButton">View</div>
            </Link>
            <div
              className="deleteButton"
              onClick={() => handleDelete(params.row.ticketNo)}
            >
              Cancel
            </div>
          </div>
        );
      },
    },
  ];

  const bookingColumns = [
    { field: "ticketNo", headerName: "Ticket No", width: 100 },
    { field: "customer", headerName: "Customer", width: 200 },
    { field: "issuedDate", headerName: "Issued Date", width: 150 },
    { field: "ticketPrice", headerName: "Price", width: 100 },
    { field: "status", headerName: "Status", width: 120 },
  ];

  return (
    <div className="datatable">
      <div className="datatableTitle">
        Bookings
        <Link to="/bookings/new" className="link">
          Add New
        </Link>
      </div>
      <DataGrid
        className="datagrid"
        rows={data}
        columns={bookingColumns.concat(actionColumn)}
        pageSize={9}
        rowsPerPageOptions={[9]}
        checkboxSelection
      />
    </div>
  );
};

export const TransactionDatatable = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/transactions');
        // Add a unique 'id' property using transactionid for each row
        const formattedData = response.data.map((item) => ({
          id: item.transactionid,  // Using transactionid as the unique identifier
          ...item
        }));
        setData(formattedData);
      } catch (err) {
        console.error('Error fetching transaction data:', err);
      }
    };
    fetchData();
  }, []);

  const handleDelete = (transactionid) => {
    setData(data.filter((item) => item.transactionid !== transactionid));
    // Optionally, you can add an axios request here to delete the transaction from the backend
  };

  const actionColumn = [
    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => {
        return (
          <div className="cellAction">
            <Link to={`/transactions/${params.row.transactionid}`} style={{ textDecoration: "none" }}>
              <div className="viewButton">View</div>
            </Link>
          </div>
        );
      },
    },
  ];

  const transactionColumns = [
    { field: "transactionid", headerName: "Transaction ID", width: 150 },
    { field: "customer", headerName: "Customer", width: 200 },
    { field: "date", headerName: "Date", width: 150 },
    { field: "amount", headerName: "Amount", width: 100 },
    { field: "type", headerName: "Type", width: 120 },
    { field: "status", headerName: "Status", width: 120 },
  ];

  return (
    <div className="datatable">
      <div className="datatableTitle">
        Transactions
        <Link to="/transactions/new" className="link">
          Add New
        </Link>
      </div>
      <DataGrid
        className="datagrid"
        rows={data}
        columns={transactionColumns.concat(actionColumn)}
        pageSize={9}
        rowsPerPageOptions={[9]}
        checkboxSelection
      />
    </div>
  );
};

export const ScheduleDatatable = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/schedules');
        setData(response.data);
      } catch (err) {
        console.error('Error fetching schedule data:', err);
      }
    };
    fetchData();
  }, []);

  const handleDelete = (id) => {
    setData(data.filter((item) => item.scheduleid !== id));
    // Add code here to delete the schedule from the backend using axios
  };

  const actionColumn = [
    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => {
        return (
          <div className="cellAction">
            <Link to={`/schedules/${params.row.scheduleid}`} style={{ textDecoration: "none" }}>
              <div className="viewButton">View</div>
            </Link>
            <div
              className="deleteButton"
              onClick={() => handleDelete(params.row.scheduleid)}
            >
              Delete
            </div>
          </div>
        );
      },
    },
  ];

  const scheduleColumns = [
    { field: "scheduleid", headerName: "ID", width: 70 },
    { field: "routeid", headerName: "Route", width: 230 },
    { field: "date", headerName: "Date", width: 160 },
    { field: "departuretime", headerName: "Time", width: 160 },
    { field: "vehicleid", headerName: "Bus ID", width: 160 },
    { field: "status", headerName: "Status", width: 160 },
  ];

  return (
    <div className="datatable">
      <div className="datatableTitle">
        Schedules
        <Link to="/schedules/new" className="link">
          Add New
        </Link>
      </div>
      <DataGrid
        className="datagrid"
        rows={data}
        columns={scheduleColumns.concat(actionColumn)}
        pageSize={9}
        rowsPerPageOptions={[9]}
        checkboxSelection
        getRowId={(row) => row.scheduleid} // Ensure you use 'scheduleid' here
      />
    </div>
  );
};

export const BusStopDatatable = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/locations');
        // Add a unique 'id' property using ticketNo for each row
        const formattedData = response.data.map((item) => ({
          id: item.LOCATIONID,  // Using ticketNo as the unique identifier
          ...item
        }));
        setData(formattedData);
      } catch (err) {
        console.error('Error fetching booking data:', err);
      }
    };
    fetchData();
  }, []);

  const handleDelete = (LOCATIONID) => {
    setData(data.filter((item) => item.LOCATIONID !== LOCATIONID));
    // Optionally, you can add an axios request here to delete the booking from the backend
  };

  const deleteColumn = [
    {
      field: "action",
      headerName: "Action",
      width: 100,
      renderCell: (params) => {
        return (
          <div className="cellAction">
            <div
              className="deleteButton"
              onClick={() => handleDelete(params.row.LOCATIONID)}
            >
              Delete
            </div>
          </div>
        );
      },
    },
  ];

  const locationColumns = [
    { field: "LOCATIONID", headerName: "Location ID", width: 100 },
    { field: "NAMEID", headerName: "Name ID", width: 100 },
    { field: "LAT", headerName: "Latitude", width: 200 },
    { field: "LNG", headerName: "Longitude", width: 200 },
  ];

  return (
    <div className="datatable">
      <div className="datatableTitle">
        Bus Stop Locations
        <Link to="/bookings/new" className="link">
          Add New
        </Link>
      </div>
      <DataGrid
        className="datagrid"
        rows={data}
        columns={locationColumns.concat(deleteColumn)}
        pageSize={9}
        rowsPerPageOptions={[9]}
        checkboxSelection
      />
    </div>
  );
};