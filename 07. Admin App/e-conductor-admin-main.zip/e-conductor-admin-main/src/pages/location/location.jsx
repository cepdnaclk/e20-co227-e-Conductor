import "./location.scss";
import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import LocationManager from "../../components/map/map";
import { BusStopDatatable } from "../../components/datatable/Datatable";

const locations = () => {
  return (
    <div className="list">
      <Sidebar />
      <div className="listContainer">
        <Navbar />
        <LocationManager />
        <BusStopDatatable/>
      </div>
    </div>
  );
};

export default locations;
