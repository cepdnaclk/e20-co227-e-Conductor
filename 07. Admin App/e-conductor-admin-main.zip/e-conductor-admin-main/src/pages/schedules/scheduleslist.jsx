import "./scheduleslist.scss";
import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import {ScheduleDatatable} from "../../components/datatable/Datatable";

const SchedulesList = () => {
  return (
    <div className="list">
      <Sidebar />
      <div className="listContainer">
        <Navbar />
        <ScheduleDatatable />
      </div>
    </div>
  );
};

export default SchedulesList;
