import "./bookings.scss";
import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import { BookingDatatable } from "../../components/datatable/Datatable";

const BookingsList = () => {
  return (
    <div className="list">
      <Sidebar />
      <div className="listContainer">
        <Navbar />
        <BookingDatatable />
      </div>
    </div>
  );
};

export default BookingsList;
