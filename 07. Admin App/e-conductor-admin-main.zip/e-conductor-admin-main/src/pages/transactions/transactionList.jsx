import "./transactionList.scss";
import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import {TransactionDatatable} from "../../components/datatable/Datatable";

const TransactionsList = () => {
  return (
    <div className="list">
      <Sidebar />
      <div className="listContainer">
        <Navbar />
        <TransactionDatatable />
      </div>
    </div>
  );
};

export default TransactionsList;
