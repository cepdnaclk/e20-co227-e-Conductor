export const userColumns = [
  { field: "id", headerName: "ID", width: 70 },
  {
    field: "user",
    headerName: "User",
    width: 230,
    renderCell: (params) => {
      return (
        <div className="cellWithImg">
          <img className="cellImg" src={params.row.img} alt="avatar" />
          {params.row.username}
        </div>
      );
    },
  },
  {
    field: "email",
    headerName: "Email",
    width: 230,
  },
  {
    field: "status",
    headerName: "Status",
    width: 160,
    renderCell: (params) => {
      return (
        <div className={`cellWithStatus ${params.row.status}`}>
          {params.row.status}
        </div>
      );
    },
  },
];

//temporary data
export const userRows = [
  {
    id: 1,
    username: "A Kumara",
    img: "https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=600",
    status: "active",
    email: "Kumara@gmail.com",
    age: 35,
  },
  {
    id: 2,
    username: "J Jayaweera",
    img: "https://images.pexels.com/photos/1820770/pexels-photo-1820770.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "Jayaweera@gmail.com",
    status: "passive",
    age: 42,
  },
  {
    id: 3,
    username: "P Silva",
    img: "https://images.pexels.com/photos/1820770/pexels-photo-1820770.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "Silva@gmail.com",
    status: "pending",
    age: 45,
  },
  {
    id: 4,
    username: "R Kapila",
    img: "https://images.pexels.com/photos/1820770/pexels-photo-1820770.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "Kapila@gmail.com",
    status: "active",
    age: 16,
  },
  {
    id: 5,
    username: "C Perera",
    img: "https://images.pexels.com/photos/1820770/pexels-photo-1820770.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "Perera@gmail.com",
    status: "passive",
    age: 22,
  },
 
];

export const bookingColumns = [
  { field: "id", headerName: "ID", width: 70 },
  { field: "customer", headerName: "User Name", width: 230 },
  { field: "date", headerName: "Date", width: 160 },
  { field: "amount", headerName: "Amount", width: 160 },
  { field: "status", headerName: "Status", width: 160 },
];

export const bookingRows = [
  { id: 1, customer: "ABC Perera", date: "18 Sep 2024", amount: "560", status: "Used" },
  { id: 2, customer: "J Jayaweera", date: "20 Sep 2024", amount: "800", status: "Refunded" },
  { id: 3, customer: "K Silva", date: "21 Sep 2024", amount: "200", status: "Available" },
  // Add more bookings here
];

export const transactionColumns = [
  { field: "id", headerName: "ID", width: 70 },
  { field: "customer", headerName: "User Name", width: 230 },
  { field: "date", headerName: "Date", width: 160 },
  { field: "amount", headerName: "Amount", width: 160 },
  { field: "type", headerName: "Type", width: 160 },
  { field: "status", headerName: "Status", width: 160 },
];

export const transactionRows = [
  { id: 1, customer: "John Doe", date: "18 Sep 2024", amount: "560", type: "Top-Up", status: "Completed" },
  { id: 2, customer: "Jamie Lannister", date: "20 Sep 2024", amount: "800", type: "Refund", status: "Pending" },
  { id: 3, customer: "Arya Stark", date: "21 Sep 2024", amount: "200", type: "Purchase", status: "Failed" },
  // Add more transactions here
];

export const scheduleColumns = [
  { field: "id", headerName: "ID", width: 70 },
  { field: "route", headerName: "Route", width: 230 },
  { field: "date", headerName: "Date", width: 160 },
  { field: "time", headerName: "Time", width: 160 },
  { field: "bus", headerName: "Bus ID", width: 160 },
  { field: "status", headerName: "Status", width: 160 },
];

export const scheduleRows = [
  { id: 1, route: "Route 1", date: "18 Sep 2024", time: "10:00 AM", bus: "Bus A", status: "On Time" },
  { id: 2, route: "Route 2", date: "18 Sep 2024", time: "12:00 PM", bus: "Bus B", status: "Delayed" },
  { id: 3, route: "Route 3", date: "18 Sep 2024", time: "02:00 PM", bus: "Bus C", status: "On Time" },
  { id: 4, route: "Route 4", date: "19 Sep 2024", time: "04:00 PM", bus: "Bus D", status: "Cancelled" },
  // Add more schedules here
];