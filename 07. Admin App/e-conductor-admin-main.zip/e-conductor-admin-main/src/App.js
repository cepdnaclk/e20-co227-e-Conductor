import Home from "./pages/home/Home";
import Login from "./pages/login/Login";
import List from "./pages/list/List";
import Single from "./pages/single/Single";
import New from "./pages/new/New";
import Locations from "./pages/location/location";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { productInputs, userInputs } from "./formSource";
import "./style/dark.scss";
import { useContext } from "react";
import { DarkModeContext } from "./context/darkModeContext";
import BookingsList from "./pages/bookings/bookings";
import TransactionsList from "./pages/transactions/transactionList";
import SchedulesList  from "./pages/schedules/scheduleslist";


function App() {
  const { darkMode } = useContext(DarkModeContext);

  return (
    <div className={darkMode ? "app dark" : "app"}>
      <BrowserRouter>
        <Routes>
          <Route path="/">
            <Route index element={<Home />} />
            <Route path="login" element={<Login />} />
            <Route path="users">
              <Route index element={<List/>} />
              <Route path=":userId" element={<Single />} />
              <Route
                path="new"
                element={<New inputs={userInputs} title="Add New User" />}
              />
            </Route>
            <Route path="bookings">
              <Route index element={<BookingsList />} />
              <Route path=":bookingId" element={<Single />} />
              <Route
                path="new"
                element={<New inputs={userInputs} title="Add New Booking" />}
              />
            </Route>
            <Route path="schedules">
              <Route index element={<SchedulesList />} />
              <Route path=":scheduleId" element={< Single />} />
              <Route
                path="new"
                element={<New inputs={productInputs} title="Add Schedule" />}
              />
            </Route>
            <Route path="transactions">
              <Route index element={<TransactionsList />} />
              <Route path=":transactionId" element={<Single />} />
              <Route
                path="new"
                element={<New inputs={productInputs} title="Add New Transaction" />}
              />
            </Route>
            <Route path="location">
              <Route index element={<Locations/>} />
            </Route>
            <Route path="fee">
            </Route>
            <Route path="profile">
            </Route>
            <Route path="logout">
            </Route>
            <Route path="logs">
            </Route>
            <Route path="Settings">
            </Route>
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}
export default App;
