import React from 'react'

export default function Topups({ language }) {
  return (
    <div className='body'>
      <h1>TOP-UPS</h1>
      <h3>Language: {language} </h3>
    </div>
  )
}



