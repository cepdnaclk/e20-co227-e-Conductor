import React from 'react'
import Footer from '../Components/Footer/Footer2'

export default function Forbidden() {
  return (
    <div className='body'>
      <h1>OOPS!!! 404 FORBIDDEN</h1>
      <Footer/>  
    </div>
  )
}



