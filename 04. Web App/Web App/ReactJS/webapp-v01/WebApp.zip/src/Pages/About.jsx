import React from 'react'

export default function About({ language }) {
  return (
    <div className='body'>
      <h1>ABOUT</h1>
      <h1>Language: {language}</h1>
    </div>
  )
}



