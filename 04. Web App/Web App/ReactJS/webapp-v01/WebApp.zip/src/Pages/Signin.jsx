import React, { useState } from 'react'
import Login from '../Components/LoginForm/login1'
import './Signin.css'
import OTP from '../Components/OTPForm/OTP1'

export default function Signin( { language } ) {
  // Variable for storing current login state.
  const [isLoging, setIsLogin] = useState(false);   // boolean
  const [user, setUser] = useState('');             // User ID or none
  const [mobile, setMobile] = useState('');         // Mobile number 
  const [email, setEmail] = useState('');           // Email

  const handleResponse = (response) =>{
    //console.log('New Login:');
    //console.log(response);
    if(response === 'none'){
      setIsLogin(false);
      setUser('');
      setMobile(''); 
      setEmail('');
    }
    else{
      setUser(response);
      setIsLogin(true);
    }
  }

  return (
    <div className='Login-body'>
      {
        !isLoging ? (
          <>
            <Login user={handleResponse} mobile={e=>{setMobile(e)}} email={e=>{setEmail(e)}} language={language}/>
          </>
        ):(
          <>
            <OTP userID={user} mobile={mobile} email={email} sendResponse={handleResponse} language={language}/>
          </>
        )
      }
    </div>
  )
}
