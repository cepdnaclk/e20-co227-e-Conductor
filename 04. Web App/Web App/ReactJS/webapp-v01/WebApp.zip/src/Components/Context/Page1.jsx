// src/Page1.js
import React from 'react';

const Page1 = () => {
  return <div>Page 1</div>;
};

export default Page1;
