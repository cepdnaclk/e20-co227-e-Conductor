// src/Page2.js
import React from 'react';

const Page2 = () => {
  return <div>Page 2</div>;
};

export default Page2;
