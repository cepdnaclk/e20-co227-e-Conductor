import { Grid, Paper } from '@mui/material'
import React, { useEffect, useState } from 'react'
import LocationForm from './Forms/LocationForm'
import Map from './MapArea/Map'

export default function Location({activeStep, setActiveStep, bookingData, setBookingData, steps}) {
  // Variables to store from location
  const location = { name: '', lng: '', lat:'', fairStage:'' };
  const [from , setFrom] = useState(location);
  const [to , setTo] = useState(location);
  const [findMe, setFindMe] = useState(false);
  
  // Variable to store booked date
  const [date , setDate] = useState('');

  // DEBUGGING
  useEffect(()=>{
    console.log(`from: ${JSON.stringify(from)}  \nto: ${JSON.stringify(to)}   \ndate: ${JSON.stringify(date)}`);
  }, [date, from, to]);

  // Handling from input
  const handleFromLocation = (e) =>{
    const {value} = e.target;
    setFrom(value);
  }

  // Handling to input
  const handleToLocation = (e) =>{
    const {value} = e.target;
    setTo(value);
  }

  // Handling continue button
  const handleClick = () =>{
    // Update booking data
    setBookingData({...bookingData, from:from, to:to, date:date});

    // Goto next step
    setActiveStep(activeStep + 1);
  }

  // Handling my location
  const findMyLocation = (e) =>{
    console.log(`Find my location: ${JSON.stringify(e.target.id)}`);
    setFindMe(true);
  }

  return (
    <Paper sx={{bgcolor:'ghostwhite', width: "100%", height:"fit-content",  display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'10px'}}>
      <Grid container sx={{width:'100%', display: 'flex', justifyContent:"space-between"}}>
        <Grid item xs={12} md={4} display='flex' justifyContent='center' alignItems='center'>
          <LocationForm 
            steps={steps} 
            activeStep={activeStep} 
            setActiveStep={setActiveStep} 
            date={date}
            setDate={setDate}
            setFrom={setFrom}
            setTo={setTo}
            handleClick={handleClick}
            handleFromLocation={handleFromLocation}
            handleToLocation={handleToLocation}
            findMyLocation={findMyLocation}
          />
        </Grid>
        
        <Grid item xs={12} md={8} display='flex' justifyContent='center' alignItems='center'>
          <Map 
            findMe={findMe}
            setFindMe={setFindMe}
          />
        </Grid>
      </Grid> 
    </Paper>
  )
}
