import React from 'react'
import BusCard from'../Components/Card/BusCard'

export default function Topups({ language }) {
  return (
    <>
    <BusCard/>
    {/* <div className='body'>
      <h1>TOP-UPS</h1>
      <h3>Language: {language} </h3>
    </div> */}
    </>
  )
}



