This is the Web App Version 1.0
Created Using React JS
Created by: Janakantha S.M.B.G.
Created on: 21-05-2024
Last Modified: 21-05-2024

------------------- USEFUL COMMANDS ------------------------
See the README.me documentation in the same directory. 

--------------------- USEFUL FONTS -------------------------
______________________________________________________________
                        Open Sans

// <uniquifier>: Use a unique and descriptive class name
// <weight>: Use a value from 300 to 800

.open-sans-<uniquifier> {
  font-family: "Open Sans", sans-serif;
  font-optical-sizing: auto;
  font-weight: <weight>;
  font-style: normal;
  font-variation-settings:
    "wdth" 100;
}
_____________________________________________________________


------------------------- LOG ------------------------------
2024-05-21 - Initiate Project Web App
2024-05-21 - 
